
import axiosInstance from '../data/AxiosConfig';

export const archiveNote = (id) => axiosInstance.patch(`/notes/${id}/archive`);
export const unarchiveNote = (id) => axiosInstance.patch(`/notes/${id}/unarchive`);
