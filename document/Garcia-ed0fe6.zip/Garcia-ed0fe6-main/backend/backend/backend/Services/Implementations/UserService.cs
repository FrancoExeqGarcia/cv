﻿using backend.Data.Models.User;
using backend.Repositories.Interfaces;
using backend.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace backend.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repository;

        public UserService (IUserRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<UserDto> GetAll()
        {
            throw new NotImplementedException();
        }

        public UserDto GetByEmailAndPassword(string email, string password)
        {
            var user = _repository.GetByEmailAndPassword(email, password);
            if (user == null)
            {
                throw new Exception("Invalid credentials");
            }
            var userDto = new UserDto()
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Password = user.Password
            };
            return userDto;
        }

        public UserDto GetById(int id)
        {
            throw new NotImplementedException();
        }

        public UserDto Update(int id, UserDto userDto)
        {
            throw new NotImplementedException();
        }

        public UserDto UpdatePassword(UpdateUserPasswordDto userDto)
        {
            throw new NotImplementedException();
        }

        UserDto IUserService.Create(CreateUserDto userDto)
        {
            throw new NotImplementedException();
        }
    }
}
