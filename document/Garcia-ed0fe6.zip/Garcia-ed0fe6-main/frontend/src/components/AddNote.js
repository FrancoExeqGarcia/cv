import React, { useState } from "react";
import Swal from "sweetalert2";
import axiosInstance from "../data/AxiosConfig";

const AddNote = ({ setNotes, setIsAdding }) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [createAt, setCreateAt] = useState("");
  const [status, setStatus] = useState(0);

  const handleAdd = async (e) => {
    e.preventDefault();

    if (!title || !content || !createAt) {
      return Swal.fire({
        icon: "error",
        title: "Error!",
        text: "All fields are required.",
        showConfirmButton: true,
      });
    }

    const newNote = {
      title,
      content,
      createAt,
      status,
    };

    try {
      const response = await axiosInstance.post("/notes", newNote);
      setNotes((prevNotes) => [...prevNotes, response.data]);
      setIsAdding(false);

      Swal.fire({
        icon: "success",
        title: "Added!",
        text: "Note has been added.",
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      console.error(
        "Error adding note:",
        error.response ? error.response.data : error.message
      );
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: error.response
          ? error.response.data
          : "Something went wrong while adding the note.",
        showConfirmButton: true,
      });
    }
  };

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-body">
          <h2 className="card-title mb-4">Add Note</h2>
          <form onSubmit={handleAdd}>
            <div className="mb-3">
              <label htmlFor="title" className="form-label">
                Title
              </label>
              <input
                id="title"
                type="text"
                className="form-control"
                name="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="content" className="form-label">
                Content
              </label>
              <textarea
                id="content"
                className="form-control"
                name="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="createAt" className="form-label">
                Creation Date
              </label>
              <input
                id="createAt"
                type="date"
                className="form-control"
                name="createAt"
                value={createAt}
                onChange={(e) => setCreateAt(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(Number(e.target.value))}
                className="form-control"
              >
                <option value={0}>Not Started</option>
                <option value={1}>In Progress</option>
                <option value={2}>Completed</option>
              </select>
            </div>

            <div className="d-flex justify-content-end">
              <button type="submit" className="btn btn-primary me-2">
                Add
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setIsAdding(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddNote;
