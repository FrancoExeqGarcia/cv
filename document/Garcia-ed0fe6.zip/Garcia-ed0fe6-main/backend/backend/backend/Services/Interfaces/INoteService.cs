﻿using backend.Data.Entities;
using backend.Data.Models;
using static backend.Services.Implementations.NoteService;

namespace backend.Services.Interfaces
{
    public interface INoteService
    {
        NoteDto GetNoteByIdAsync(int id);
        List<NoteDto> GetAllNotesAsync();
        NoteDto Create(CreateNoteDto noteDto);
        NoteDto UpdateNoteAsync(int id, UpdateNoteDto noteDto);
        NoteDto ArchiveNoteAsync(int id);
        NoteDto UnarchiveNoteAsync(int id);
        NoteCountDto GetNotesCount();
        List<NoteDto> GetActiveNotes();
        List<NoteDto> GetArchivedNotes();
        void Delete(int id);

        void AddTagsToNoteAsync(int noteId, AddTagsToNoteDto dto);
        void RemoveTagsFromNoteAsync(int noteId, RemoveTagsFromNoteDto dto);
    }
}
