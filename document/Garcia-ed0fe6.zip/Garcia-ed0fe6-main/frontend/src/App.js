import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import NoteList from './components/NoteList';
import AddNote from './components/AddNote';
import Login from './components/Login';
import Navbar from './components/Navbar';

const App = () => {
  return (
    <Router>
      <Navbar />
      <div className="App">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<NoteList />} />
          <Route path="/" element={<AddNote />} />

        </Routes>
      </div>
    </Router>
  );
};

export default App;
