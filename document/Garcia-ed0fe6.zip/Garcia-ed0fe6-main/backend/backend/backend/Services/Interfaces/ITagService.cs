﻿using backend.Data.Entities;
using backend.Data.Models;
using backend.Data.Models.Tag;
using System.Collections.Generic;

namespace backend.Services.Interfaces
{
    public interface ITagService
    {
        TagDto CreateTag(CreateTagDto dto);
        void DeleteTag(int id);
        IEnumerable<TagDto> GetAllTags();
        TagDto GetTagById(int id);
        IEnumerable<NoteDto> GetNotesByTag(int tagId);
    }
}
