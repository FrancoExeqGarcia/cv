﻿namespace backend.Data.Models.Tag
{
    public class TagDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
