﻿namespace backend.Services.Interfaces
{
    public interface ITokenService
    {
        public int GetUserId();

    }
}
