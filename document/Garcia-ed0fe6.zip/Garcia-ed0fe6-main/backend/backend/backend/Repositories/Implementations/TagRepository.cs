﻿using backend.Context;
using backend.Data.Entities;
using backend.Repositories.Interfaces;

public class TagRepository : ITagRepository
{
    private readonly AppDbContext _dbContext;

    public TagRepository(AppDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public List<Tag> GetAll() => _dbContext.Tags.ToList();
    public Tag GetById(int id) => _dbContext.Tags.Find(id);
    public Tag Create(Tag entity)
    {
        _dbContext.Tags.Add(entity);
        _dbContext.SaveChanges();
        return entity;
    }
    public Tag UpdateAsync(int id, Tag entity)
    {
        _dbContext.Tags.Update(entity);
        _dbContext.SaveChanges();
        return entity;
    }
    public void Delete(int id)
    {
        var tag = _dbContext.Tags.Find(id);
        if (tag != null)
        {
            _dbContext.Tags.Remove(tag);
            _dbContext.SaveChanges();
        }
    }

    public void AddTagsToEntity(int entityId, List<int> tagIds)
    {
        // Implementa la lógica aquí según tu necesidad
    }

    public void RemoveTagsFromEntity(int entityId, List<int> tagIds)
    {
        // Implementa la lógica aquí según tu necesidad
    }

    public List<Tag> GetByIds(List<int> ids)
    {
        throw new NotImplementedException();
    }
}
