﻿using System.ComponentModel.DataAnnotations;
using static backend.Data.Entities.Note;

namespace backend.Data.Models
{
    public class CreateNoteDto
    {
        [Required]
        public string Title { get; set; } = string.Empty;
        [Required]
        public string Content { get; set; }
        [Required]
        public DateTime CreateAt { get; set; }
        [Required]
        public NoteStatus Status { get; set; } 

    }
}
