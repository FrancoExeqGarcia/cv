﻿namespace backend.Data.Models
{
    public class RemoveTagsFromNoteDto
    {
        public List<int> TagIds { get; set; } = new List<int>();
    }
}
