﻿using backend.Data.Entities;

namespace backend.Repositories.Interfaces
{
    public interface IUserRepository : ICRUDRepository<User>
    {
        User GetByEmailAndPassword(string email, string password);

    }
}
