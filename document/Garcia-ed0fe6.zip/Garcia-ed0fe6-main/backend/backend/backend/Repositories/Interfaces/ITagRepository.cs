﻿using backend.Data.Entities;

namespace backend.Repositories.Interfaces
{
    public interface ITagRepository : ICRUDRepository<Tag>
    {
        List<Tag> GetByIds(List<int> ids); 

    }
}
