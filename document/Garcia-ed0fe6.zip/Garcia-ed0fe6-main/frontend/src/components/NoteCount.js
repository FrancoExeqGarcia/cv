import React, { useState, useEffect } from 'react';
import axiosInstance from '../data/AxiosConfig';
import Swal from 'sweetalert2';

const NoteCount = () => {
  const [noteCounts, setNoteCounts] = useState({ activeNotesCount: 0, archivedNotesCount: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNoteCounts = async () => {
      try {
        const response = await axiosInstance.get('/notes/counts');
        setNoteCounts(response.data);
      } catch (error) {
        console.error('Error fetching note counts:', error);
        Swal.fire({
          icon: 'error',
          title: 'Error!',
          text: 'Something went wrong while fetching note counts.',
          showConfirmButton: true,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchNoteCounts();
  }, []);
  const refreshCounts = async () => {
    try {
      const response = await axiosInstance.get('/notes/counts');
      setNoteCounts(response.data);
    } catch (error) {
      console.error('Error refreshing note counts:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Something went wrong while refreshing note counts.',
        showConfirmButton: true,
      });
    }
  };

  const handleNoteArchived = () => {
    refreshCounts();
  };

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Note Counts</h2>
        </div>
        <div className="card-body">
          <p className="card-text">Active Notes: {noteCounts.activeNotesCount}</p>
          <p className="card-text">Archived Notes: {noteCounts.archivedNotesCount}</p>
        </div>
      </div>
    </div>
  );
};

export default NoteCount;
