import React from "react";
import Swal from "sweetalert2";

const ArchivedList = ({ archivedNotes, handleEditClick, handleUnarchive, handleDelete }) => {
  const handleUnarchiveClick = (id, event) => {
    event.stopPropagation();

    Swal.fire({
      title: 'Are you sure?',
      text: "You are about to unarchive this note.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, unarchive it!'
    }).then((result) => {
      if (result.isConfirmed) {
        handleUnarchive(id);
      }
    });
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Archived Notes</h2>
      <ul className="list-group">
        {archivedNotes.map((note) => (
          <li
            key={note.id}
            onClick={() => handleEditClick(note)}
            className="list-group-item d-flex justify-content-between align-items-center flex-column flex-sm-row"
            style={{ cursor: "pointer" }}
          >
            <div className="w-100 d-flex justify-content-between align-items-center">
              <span>{note.title}</span>
              <div className="btn-group mt-2 mt-sm-0" role="group" aria-label="Actions">
                <button
                  onClick={(event) => {
                    event.stopPropagation();
                    handleEditClick(note);
                  }}
                  className="btn btn-warning btn-sm me-2"
                >
                  Edit
                </button>
                <button
                  onClick={(event) => handleDelete(note.id, event)}
                  className="btn btn-danger btn-sm me-2"
                >
                  Delete
                </button>
                <button
                  onClick={(event) => {
                    event.stopPropagation();
                    handleUnarchiveClick(note.id, event);
                  }}
                  className="btn btn-secondary btn-sm"
                >
                  Unarchive
                </button>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ArchivedList;
