﻿namespace backend.Data.Models
{
    public class CreateTagDto
    {
        public string Name { get; set; } = string.Empty;
    }
}
