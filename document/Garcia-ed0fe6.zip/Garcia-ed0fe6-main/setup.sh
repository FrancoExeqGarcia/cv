#!/bin/bash

# Check if the correct number of arguments are provided
if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <path_to_dotnet_project> <path_to_react_project>"
  exit 1
fi

# Project paths
DOTNET_PROJECT_PATH=$1
REACT_PROJECT_PATH=$2

# Database configuration
echo "Configuring the database..."

# Connection parameters
SERVER_NAME="localhost"
DATABASE_NAME="LOCAL"
USERNAME="your_username"  # Replace with your SQL Server username
PASSWORD="your_password"  # Replace with your SQL Server password

# SQL commands to create the database and tables
# Save these commands in .sql files and use sqlcmd to execute them.

# Create database
echo "CREATE DATABASE $DATABASE_NAME" | sqlcmd -S $SERVER_NAME -U $USERNAME -P $PASSWORD

# Execute the table creation SQL file
sqlcmd -S $SERVER_NAME -U $USERNAME -P $PASSWORD -d $DATABASE_NAME -i create_tables.sql

# Start the .NET application
echo "Starting the .NET application..."
cd $DOTNET_PROJECT_PATH
dotnet run &

# Start the React application
echo "Starting the React application..."
cd $REACT_PROJECT_PATH
npm start &

echo "All set up!"
