﻿using backend.Data.Entities;

namespace backend.Repositories.Interfaces
{
    public interface INoteRepository : ICRUDRepository<Note>
    {
    }
}
