﻿using Microsoft.EntityFrameworkCore;
using backend.Context;
using backend.Repositories.Interfaces;
using backend.Data.Entities;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace backend.Repositories.Implementations
{
    public class CRUDRepository<T> : ICRUDRepository<T> where T : BaseEntity, IHasTags
    {
        protected readonly AppDbContext _context;
        private readonly DbSet<T> _dbSet;

        public CRUDRepository(AppDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        public void AddTagsToEntity(int entityId, List<int> tagIds)
        {
            var entity = _context.Set<T>().Find(entityId);
            if (entity == null) throw new Exception("Entity not found");

            foreach (var tagId in tagIds)
            {
                var tag = _context.Tags.Find(tagId);
                if (tag != null)
                {
                    entity.Tags.Add(tag);
                }
            }
            _context.SaveChanges();
        }

        public void RemoveTagsFromEntity(int entityId, List<int> tagIds)
        {
            var entity = _context.Set<T>().Find(entityId);
            if (entity == null) throw new Exception("Entity not found");

            foreach (var tagId in tagIds)
            {
                var tag = entity.Tags.SingleOrDefault(t => t.Id == tagId);
                if (tag != null)
                {
                    entity.Tags.Remove(tag);
                }
            }
            _context.SaveChanges();
        }

        public virtual T Create(T entity)
        {
            var result = _context.Add(entity);
            _context.SaveChanges();
            return result.Entity;
        }

        public virtual void Delete(int id)
        {
            var found = _context.Set<T>().SingleOrDefault(x => x.Id == id);
            if (found == null)
                throw new Exception("Entity not found");
            _context.Set<T>().Remove(found);

            try
            {
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                if (ex.InnerException is SqlException sqlEx && sqlEx.Number == 547)
                {
                    throw new InvalidOperationException("Cannot be deleted", ex);
                }
                throw;
            }
        }

        public virtual List<T> GetAllAsync()
            => _context.Set<T>().ToList();

        public virtual T? GetById(int id)
            => _context.Set<T>().SingleOrDefault(e => e.Id == id);

        public virtual T UpdateAsync(int id, T entity)
        {
            _context.Set<T>().Update(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task ArchiveAsync(int id)
        {
            var note = await _context.Notes.FindAsync(id);
            if (note != null)
            {
                note.IsArchived = true;
                await _context.SaveChangesAsync();
            }
        }

        public async Task UnarchiveAsync(int id)
        {
            var note = await _context.Notes.FindAsync(id);
            if (note != null)
            {
                note.IsArchived = false;
                await _context.SaveChangesAsync();
            }
        }


        public List<T> GetAll()
            => _context.Set<T>().ToList();
    }
}
