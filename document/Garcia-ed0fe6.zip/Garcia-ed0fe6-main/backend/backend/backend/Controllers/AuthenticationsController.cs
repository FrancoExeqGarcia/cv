﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using backend.Data.Models.User;
using backend.Services.Interfaces;
using Microsoft.AspNetCore.Cors;
namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class AuthenticationsController : ControllerBase
    {
        public IUserService _userService;
        public IConfiguration _config;

        public AuthenticationsController(IUserService userService, IConfiguration config)
        {
            _userService = userService;
            _config = config;
        }

        [HttpPost]
        public IActionResult Authenticate([FromBody] CredentialsDto credentialsDto)
        {
            if (credentialsDto != null && credentialsDto.Email != null && credentialsDto.Password != null)
            {
                
                var userDto = new UserDto();
                try
                {
                    userDto = _userService.GetByEmailAndPassword(credentialsDto.Email, credentialsDto.Password);
                }
                catch (Exception ex)
                {
                    return Unauthorized();
                }

                var securityPassword = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_config["Authentication:SecretForKey"]));
                var signature = new SigningCredentials(securityPassword, SecurityAlgorithms.HmacSha256);

                var claimsForToken = new List<Claim>();
                claimsForToken.Add(new Claim("sub", userDto.Id.ToString())); 
                claimsForToken.Add(new Claim("email", userDto.Email));
                claimsForToken.Add(new Claim("username", userDto.Name));

                var jwtSecurityToken = new JwtSecurityToken(
                    _config["Authentication:Issuer"],
                    _config["Authentication:Audience"],
                    claimsForToken,
                    DateTime.UtcNow,
                    DateTime.UtcNow.AddHours(1),
                    signature);

                string tokenToReturn = new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
                return Ok(tokenToReturn);
            }
            else
            {
                return BadRequest("Complete todos los campos");
            }
        }
    }
}
