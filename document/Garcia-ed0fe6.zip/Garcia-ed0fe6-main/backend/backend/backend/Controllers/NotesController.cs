﻿using backend.Data.Models;
using backend.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static backend.Services.Implementations.NoteService;

namespace backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]

    public class NotesController : ControllerBase
    {
        private readonly INoteService _noteService;
        public NotesController(INoteService noteService)
        {
            _noteService = noteService;
        }

        [HttpPost]
        public ActionResult<NoteDto> Create([FromBody] CreateNoteDto request)
        {
            var createNoteDto = _noteService.Create(request);

            return CreatedAtAction(nameof(GetById), new { id = createNoteDto.Id }, createNoteDto);
        }

        [HttpPut("{id}")]
        public ActionResult<NoteDto> Update(int id, [FromBody] UpdateNoteDto request)
        {
            try
            {
                var updatedNoteDto = _noteService.UpdateNoteAsync(id, request);
                return Ok(updatedNoteDto);
            }
            catch (Exception ex)
            {
                return NotFound(ex);
            }
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            try
            {
                _noteService.Delete(id);

                return NoContent();
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpGet]
        public ActionResult<NoteDto> GetAll()
        {
            var noteDto = _noteService.GetAllNotesAsync();
            return Ok(noteDto);
        }

        [HttpGet("{id}")]
        public ActionResult<NoteDto> GetById(int id)
        {
            try
            {
                var noteDto = _noteService.GetNoteByIdAsync(id);

                return Ok(noteDto);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpPatch("{id}/archive")]
        public IActionResult Archive(int id)
        {
            var note = _noteService.GetNoteByIdAsync(id);
            if (note == null)
            {
                return NotFound();
            }

            _noteService.ArchiveNoteAsync(id);
            return NoContent();
        }
        [HttpPatch("{id}/unarchive")]
        public IActionResult Unarchive(int id)
        {
            try
            {
                var noteDto = _noteService.UnarchiveNoteAsync(id);
                return Ok(noteDto); // Devuelve el estado actualizado de la nota
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpGet("counts")]
        public ActionResult<NoteCountDto> GetNotesCount()
        {
            var counts = _noteService.GetNotesCount();
            return Ok(counts);
        }

        [HttpGet("active")]
        public ActionResult<List<NoteDto>> GetActiveNotes()
        {
            var notes = _noteService.GetActiveNotes();
            return Ok(notes);
        }

        [HttpGet("archived")]
        public ActionResult<List<NoteDto>> GetArchivedNotes()
        {
            var notes = _noteService.GetArchivedNotes();
            return Ok(notes);
        }

    }
}
