import React from "react";
import Swal from "sweetalert2";
import '../App.css'; 
import '../index.css'; 

const ActiveList = ({ activeNotes, handleEditClick, handleArchive, handleDelete }) => {
  const statusMap = {
    0: "Not Started",
    1: "In Progress",
    2: "Completed"
  };

  const handleArchiveClick = (id, event) => {
    event.stopPropagation();

    Swal.fire({
      title: 'Are you sure?',
      text: "You are about to archive this note.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, archive it!'
    }).then((result) => {
      if (result.isConfirmed) {
        handleArchive(id);
      }
    });
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Active Notes</h2>
      <div className="row">
      {activeNotes.map((note) => {
  console.log(`Note ID: ${note.id}, Status: ${note.status}, Type: ${typeof note.status}`);
  return (
    <div key={note.id} className="col-md-5 mb-2">
      <div className="card h-100">
        <div className="card-body d-flex flex-column">
          <h5 className="card-title text-truncate">{note.title}</h5>
          <p className="card-text">Status: {statusMap[note.status] || 'Unknown'}</p>
          <div className="mt-auto btn-group" role="group" aria-label="Actions">
            <button
              onClick={(event) => {
                event.stopPropagation();
                handleEditClick(note);
              }}
              className="btn btn-warning btn-extra-small me-2"
            >
              Edit
            </button>
            <button
              onClick={(event) => handleDelete(note.id, event)}
              className="btn btn-danger btn-extra-small me-2"
            >
              Delete
            </button>
            <button
              onClick={(event) => {
                event.stopPropagation();
                handleArchiveClick(note.id, event);
              }}
              className="btn btn-secondary btn-extra-small"
            >
              Archive
            </button>
          </div>
        </div>
      </div>
    </div>
  );
})}

      </div>
    </div>
  );
};

export default ActiveList;
