﻿using System.Collections.Generic;

namespace backend.Data.Entities
{
    public interface IHasTags
    {
        ICollection<Tag> Tags { get; set; }

    }
}
