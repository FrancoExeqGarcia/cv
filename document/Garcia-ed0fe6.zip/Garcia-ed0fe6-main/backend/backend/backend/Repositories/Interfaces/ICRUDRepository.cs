﻿using backend.Data.Entities;
using backend.Data.Models;
using System.Collections.Generic;

namespace backend.Repositories.Interfaces
{
    public interface ICRUDRepository<T> where T : BaseEntity, IHasTags
    {
        List<T> GetAll();
        T? GetById(int id);
        T Create(T entity);
        T UpdateAsync(int id, T entity);
        void Delete(int id);

        void AddTagsToEntity(int entityId, List<int> tagIds);
        void RemoveTagsFromEntity(int entityId, List<int> tagIds);
    }
}
