import axios from 'axios';

const apiUrl = 'https://localhost:7117/api';

const axiosInstance = axios.create({
  baseURL: apiUrl, 
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosInstance.interceptors.request.use(config => {
  const token = localStorage.getItem('token'); 
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

export default axiosInstance;

export const getNoteById = (id) => axiosInstance.get(`/notes/${id}`).then(response => response.data);
export const updateNote = (id, noteData) => axiosInstance.put(`/notes/${id}`, noteData).then(response => response.data);
export const createNote = (noteData) => axiosInstance.post('/notes', noteData).then(response => response.data);
