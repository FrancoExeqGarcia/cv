﻿using backend.Data.Entities;
using backend.Data.Models;
using backend.Repositories.Implementations;
using backend.Repositories.Interfaces;
using backend.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using static backend.Data.Entities.Note;

namespace backend.Services.Implementations
{
    public class NoteService : INoteService
    {
        private readonly INoteRepository _noteRepository;
        private readonly ITagRepository _tagRepository; 

        public NoteService(INoteRepository noteRepository, ITagRepository tagRepository)
        {
            _noteRepository = noteRepository;
            _tagRepository = tagRepository;

        }
        public void AddTagsToNoteAsync(int noteId, AddTagsToNoteDto dto)
        {
            var note = _noteRepository.GetById(noteId) ?? throw new Exception("Note not found");
            var tags = _tagRepository.GetByIds(dto.TagIds);
            foreach (var tag in tags)
            {
                note.NoteTags.Add(new NoteTag { NoteId = noteId, TagId = tag.Id });
            }

            _noteRepository.UpdateAsync(noteId, note);
        }

        public void RemoveTagsFromNoteAsync(int noteId, RemoveTagsFromNoteDto dto)
        {
            var note = _noteRepository.GetById(noteId);
            if (note == null)
            {
                throw new Exception("Note not found");
            }

            foreach (var tagId in dto.TagIds)
            {
                var noteTag = note.NoteTags.FirstOrDefault(nt => nt.TagId == tagId);
                if (noteTag != null)
                {
                    note.NoteTags.Remove(noteTag);
                }
            }

            _noteRepository.UpdateAsync(noteId, note);
        }
        public NoteDto Create(CreateNoteDto request)
        {
            var note = new Note()
            {
                Title = request.Title,
                Content = request.Content,
                CreateAt = request.CreateAt,
                IsArchived = false,
                Status = request.Status,
                ArchivedAt = null 
            };

            var createdNote = _noteRepository.Create(note);

            return new NoteDto()
            {
                Id = createdNote.Id,
                Title = createdNote.Title,
                Content = createdNote.Content,
                CreateAt = createdNote.CreateAt,
                ArchivedAt = createdNote.ArchivedAt,
                Status = createdNote.Status,
                IsArchived = createdNote.IsArchived
            };
        }

        public void Delete(int id)
        {
            var noteDelete = _noteRepository.GetById(id);
            if (noteDelete == null)
            {
                throw new Exception("Note not found");
            }
            _noteRepository.Delete(id);
        }

        public List<NoteDto> GetAllNotesAsync()
        {
            var notes = _noteRepository.GetAll();

            var noteDtoList = new List<NoteDto>();
            foreach (var note in notes)
            {
                noteDtoList.Add(new NoteDto()
                {
                    Id = note.Id,
                    Title = note.Title,
                    Content = note.Content,
                    CreateAt = note.CreateAt,
                    ArchivedAt = note.ArchivedAt,
                    IsArchived = note.IsArchived
                });
            }

            return noteDtoList;
        }
        public NoteDto UpdateNoteAsync(int id, UpdateNoteDto noteDto)
        {
            var foundNote = _noteRepository.GetById(id)
                ?? throw new Exception("Note not found");

            foundNote.Title = noteDto.Title;
            foundNote.Content = noteDto.Content;
            foundNote.CreateAt = noteDto.CreateAt;
            foundNote.Status = noteDto.Status;
            var updatedNote = _noteRepository.UpdateAsync(id, foundNote);

            return new NoteDto()
            {
                Id = updatedNote.Id,
                Title = updatedNote.Title,
                Content = updatedNote.Content,
                CreateAt = updatedNote.CreateAt,
                ArchivedAt = updatedNote.ArchivedAt,
                IsArchived = updatedNote.IsArchived,
                Status = updatedNote.Status
            };
        }
        public NoteDto GetNoteByIdAsync(int id)
        {
            var note = _noteRepository.GetById(id);

            if (note == null)
                throw new Exception("Note not found");

            var updatedNoteDto = new NoteDto()
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt

            };
            return updatedNoteDto;
        }

        public NoteDto ArchiveNoteAsync(int id)
        {
            var note = _noteRepository.GetById(id);
            if (note == null)
            {
                throw new Exception("Note not found");
            }

            note.IsArchived = true;
            note.ArchivedAt = DateTime.UtcNow;
            _noteRepository.UpdateAsync(id, note);

            return new NoteDto
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt,
                ArchivedAt = note.ArchivedAt,
                IsArchived = note.IsArchived
            };
        }
        public NoteDto UnarchiveNoteAsync(int id)
        {
            var note = _noteRepository.GetById(id);
            if (note == null)
            {
                throw new Exception("Note not found");
            }

            note.IsArchived = false;
            _noteRepository.UpdateAsync(id, note);

            return new NoteDto
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt,
                ArchivedAt = note.ArchivedAt,
                IsArchived = note.IsArchived
            };
        }

        public class NoteCountDto
        {
            public int ActiveNotesCount { get; set; }
            public int ArchivedNotesCount { get; set; }
        }

        public NoteCountDto GetNotesCount()
        {
            var activeCount = _noteRepository.GetAll().Count(note => !note.IsArchived);
            var archivedCount = _noteRepository.GetAll().Count(note => note.IsArchived);

            return new NoteCountDto
            {
                ActiveNotesCount = activeCount,
                ArchivedNotesCount = archivedCount
            };
        }
        public List<NoteDto> GetActiveNotes()
        {
            var notes = _noteRepository.GetAll().Where(note => !note.IsArchived).ToList();
            return notes.Select(note => new NoteDto
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt,
                ArchivedAt = note.ArchivedAt,
                IsArchived = note.IsArchived
            }).ToList();
        }

        public List<NoteDto> GetArchivedNotes()
        {
            var notes = _noteRepository.GetAll().Where(note => note.IsArchived).ToList();
            return notes.Select(note => new NoteDto
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt,
                ArchivedAt = note.ArchivedAt,
                IsArchived = note.IsArchived
            }).ToList();
        }
    }
}
            