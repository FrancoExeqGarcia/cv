import React, { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import axiosInstance from '../data/AxiosConfig';

const EditNote = ({ note, setNotes, setIsEditing }) => {
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [createAt, setCreateAt] = useState(note.createAt);
  const [status, setStatus] = useState(note.status || 0);

  useEffect(() => {
    setTitle(note.title);
    setContent(note.content);
    setCreateAt(note.createAt ? formatDate(note.createAt) : '');
    setStatus(note.status || 0); // Se asegura que el status sea un número
  }, [note]);

  const formatDate = dateStr => {
    const date = new Date(dateStr);
    return date.toISOString().split('T')[0];
  };

  const handleEdit = async e => {
    e.preventDefault();
    if (!title || !content || !createAt) {
      return Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'All fields are required.',
        showConfirmButton: true,
      });
    }

    const updatedNote = {
      title,
      content,
      createAt,
      status: Number(status), // Convertir status a número antes de enviar
    };

    try {
      const response = await axiosInstance.put(`/notes/${note.id}`, updatedNote);
      setNotes(prevNotes =>
        prevNotes.map(n => (n.id === note.id ? response.data : n))
      );
      setIsEditing(false);

      Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: 'Note has been updated.',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      console.error('Error updating note:', error.response ? error.response.data.errors : error.message);
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: error.response ? JSON.stringify(error.response.data.errors) : 'Something went wrong while updating the note.',
        showConfirmButton: true,
      });
    }
  };

  return (
    <div className="container mt-4">
      <form onSubmit={handleEdit} className="form-group">
        <h1>Edit Note</h1>
        <div className="mb-3">
          <label htmlFor="title" className="form-label">Title</label>
          <input
            id="title"
            type="text"
            name="title"
            className="form-control"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="content" className="form-label">Content</label>
          <textarea
            id="content"
            name="content"
            className="form-control"
            rows="4"
            value={content}
            onChange={e => setContent(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="createAt" className="form-label">Creation Date</label>
          <input
            id="createAt"
            type="date"
            name="createAt"
            className="form-control"
            value={createAt}
            onChange={e => setCreateAt(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="status" className="form-label">Status</label>
          <select
            id="status"
            className="form-select"
            value={status}
            onChange={e => setStatus(e.target.value)}
          >
            <option value="0">Not Started</option>
            <option value="1">Started</option>
            <option value="2">Complete</option>
          </select>
        </div>
        <div className="mt-4">
          <button type="submit" className="btn btn-primary">Update</button>
          <button
            type="button"
            className="btn btn-secondary ms-2"
            onClick={() => setIsEditing(false)}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditNote;
