﻿namespace backend.Data.Models
{
    public class AddTagsToNoteDto
    {
        public List<int> TagIds { get; set; } = new List<int>();
    }
}
