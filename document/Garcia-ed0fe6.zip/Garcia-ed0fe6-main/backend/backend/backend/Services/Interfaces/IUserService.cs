﻿using backend.Data.Models.User;
using backend.Repositories.Interfaces;
using backend.Data.Entities;

namespace backend.Services.Interfaces
{
    public interface IUserService
    {
        List<UserDto> GetAll();
        UserDto GetById(int id);
        UserDto Create(CreateUserDto userDto);
        UserDto Update(int id, UserDto userDto);
        UserDto UpdatePassword(UpdateUserPasswordDto userDto);
        void Delete(int id);
        UserDto GetByEmailAndPassword(string email, string password);

    }
}
