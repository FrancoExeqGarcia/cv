﻿using backend.Context;
using backend.Data.Entities;
using backend.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace backend.Repositories.Implementations
{
    public class UserRepository : CRUDRepository<User>, IUserRepository
    {

        public UserRepository (AppDbContext dbContext) : base(dbContext)
        {
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<User> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public User GetByEmailAndPassword(string email, string password)
        {
            var user = _context
                .Users
                .First(e => e.Email == email && e.Password == password);

            return user;
        }

        public User? GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public User UpdateAsync(int id, User entity)
        {
            throw new NotImplementedException();
        }
    }
}
