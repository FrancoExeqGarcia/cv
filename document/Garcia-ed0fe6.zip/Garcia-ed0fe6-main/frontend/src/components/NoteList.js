import React, { useState, useEffect } from "react";
import axiosInstance from "../data/AxiosConfig";
import AddNote from "./AddNote";
import EditNote from "./EditNote";
import Swal from "sweetalert2";
import NoteCount from "./NoteCount";
import { useNavigate } from 'react-router-dom';
import ActiveList from './ActiveList';
import ArchivedList from './ArchivedList';
import { archiveNote, unarchiveNote } from './noteService'; 

const NoteList = () => {
  const [activeNotes, setActiveNotes] = useState([]);
  const [archivedNotes, setArchivedNotes] = useState([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentNote, setCurrentNote] = useState(null);
  const navigate = useNavigate();

  const fetchNotes = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }
  
    try {
      const response = await axiosInstance.get("/notes", {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const notes = response.data;
  
      const active = notes.filter((note) => !note.isArchived);
      const archived = notes.filter((note) => note.isArchived);
  
      setActiveNotes(active);
      setArchivedNotes(archived);
    } catch (error) {
      console.error("Error fetching notes:", error);
      if (error.response && error.response.status === 401) {
        navigate('/login');
      }
    }
  };

  useEffect(() => {
    fetchNotes();
  }, [navigate]);

  const handleArchive = async (id) => {
    try {
      await archiveNote(id);
      await fetchNotes();
      Swal.fire("Archived!", "Note has been archived.", "success");
    } catch (error) {
      console.error("Error archiving note:", error);
      if (error.response && error.response.status === 401) {
        navigate('/login');
      }
      Swal.fire("Error!", "Something went wrong while archiving the note.", "error");
    }
  };

  const handleUnarchive = async (id) => {
    try {
      await unarchiveNote(id);
      await fetchNotes();
      Swal.fire("Unarchived!", "Note has been unarchived.", "success");
    } catch (error) {
      console.error("Error unarchiving note:", error);
      if (error.response && error.response.status === 401) {
        navigate('/login');
      }
      Swal.fire("Error!", "Something went wrong while unarchiving the note.", "error");
    }
  };

  const handleEditClick = (note) => {
    setCurrentNote(note);
    setIsEditing(true);
  };

  const handleDelete = async (id, event) => {
    event.stopPropagation();
  
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "This action cannot be undone!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      try {
        await axiosInstance.delete(`/notes/${id}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        await fetchNotes();
        Swal.fire("Deleted!", "Note has been deleted.", "success");
      } catch (error) {
        console.error("Error deleting note:", error);
        if (error.response && error.response.status === 401) {
          navigate('/login');
        }
        Swal.fire("Error!", "Something went wrong while deleting the note.", "error");
      }
    }
  };

  return (
    <div className="container mt-4">
      <h1 className="mb-4">Notes</h1>
      <NoteCount
        activeCount={activeNotes.length}
        archivedCount={archivedNotes.length}
      />
      <div className="mb-4">
        <button className="btn btn-primary" onClick={() => setIsAdding(true)}>
          Add Note
        </button>
      </div>
      <div className="row">
        <div className="col-md-8">
          <ActiveList
            activeNotes={activeNotes}
            handleEditClick={handleEditClick}
            handleArchive={handleArchive}
            handleDelete={handleDelete}
          />
        </div>
        <div className="col-md-4">
          <ArchivedList
            archivedNotes={archivedNotes}
            handleEditClick={handleEditClick}
            handleUnarchive={handleUnarchive}
            handleDelete={handleDelete}
          />
        </div>
      </div>
      {isAdding && (
        <AddNote setNotes={fetchNotes} setIsAdding={setIsAdding} />
      )}
      {isEditing && currentNote && (
        <EditNote
          note={currentNote}
          setNotes={fetchNotes}
          setIsEditing={setIsEditing}
        />
      )}
    </div>
  );
};

export default NoteList;
