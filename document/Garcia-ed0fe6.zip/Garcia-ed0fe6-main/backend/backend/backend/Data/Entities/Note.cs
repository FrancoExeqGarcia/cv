﻿using backend.Repositories.Interfaces;
using System.Collections.Generic;

namespace backend.Data.Entities
{
    public class Note : BaseEntity, IHasTags
    {
        public enum NoteStatus
        {
            NotStarted = 0,
            InProgress = 1,
            Completed = 2
        }
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public bool IsArchived { get; set; }
        public DateTime CreateAt { get; set; } = DateTime.Now;
        public DateTime? ArchivedAt { get; set; }
        public NoteStatus Status { get; set; } = NoteStatus.NotStarted;

        public ICollection<NoteTag> NoteTags { get; set; } = new HashSet<NoteTag>();
        public ICollection<Tag> Tags { get; set; } = new HashSet<Tag>();



    }
}
