import React from 'react';
import { Link } from 'react-router-dom';

const NoteItem = ({ note, onDelete }) => {
  return (
    <div>
      <h3>{note.title}</h3>
      <p>{note.content}</p>
      <button onClick={() => onDelete(note.id)}>Delete</button>
      <Link to={`/edit/${note.id}`}>Edit</Link>
    </div>
  );
};

export default NoteItem;
