﻿using backend.Data.Entities;
using backend.Repositories.Interfaces;
using backend.Context;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend.Repositories.Implementations
{
    public class NoteRepository : CRUDRepository<Note>, INoteRepository
    {
        public NoteRepository(AppDbContext dbContext) : base(dbContext)
        {
        }

        public async Task AddTagsToEntity(int noteId, List<int> tagIds)
        {
            var note = await _context.Notes
                .Include(n => n.NoteTags)
                .SingleOrDefaultAsync(n => n.Id == noteId);

            if (note == null)
            {
                throw new Exception("Note not found");
            }

            var tags = await _context.Tags
                .Where(t => tagIds.Contains(t.Id))
                .ToListAsync();

            if (tags.Count != tagIds.Count)
            {
                throw new Exception("One or more tags not found");
            }

            foreach (var tag in tags)
            {
                if (!note.NoteTags.Any(nt => nt.TagId == tag.Id))
                {
                    note.NoteTags.Add(new NoteTag { NoteId = noteId, TagId = tag.Id });
                }
            }

            await _context.SaveChangesAsync();
        }

        public async Task RemoveTagsFromEntity(int noteId, List<int> tagIds)
        {
            var note = await _context.Notes
                .Include(n => n.NoteTags)
                .SingleOrDefaultAsync(n => n.Id == noteId);

            if (note == null)
            {
                throw new Exception("Note not found");
            }

            var tagsToRemove = note.NoteTags
                .Where(nt => tagIds.Contains(nt.TagId))
                .ToList();

            foreach (var tag in tagsToRemove)
            {
                _context.NoteTags.Remove(tag);
            }

            await _context.SaveChangesAsync();
        }

    }
}
