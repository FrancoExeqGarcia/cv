﻿namespace backend.Data.Entities
{
    public abstract class BaseEntity : IHasTags
    { 
        public int Id { get; set; }
        public ICollection<Tag> Tags { get; set; } = new List<Tag>();

    }
}
