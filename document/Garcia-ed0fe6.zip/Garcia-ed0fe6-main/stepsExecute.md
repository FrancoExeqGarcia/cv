How to Run the Application

Follow these steps to set up and run the application:

1. **Clone the Repository**

   Clone the repository to your local machine using the following command:

   ```bash
   git clone <repository-url>


Replace <repository-url> with the URL of your repository.

2. Set Up the SQL Server Database

Start SQL Server: Ensure that your SQL Server instance is running.

Configure the Database:

Open SQL Server Management Studio (SSMS).
Create a new database named NotesAppDb if it does not already exist.
Update Connection String:

Ensure your appsettings.json file in the .NET project has the correct connection string. It should look like this:

"ConnectionStrings": {
  "DefaultConnection": "Server=.\\LOCAL;Database=NotesAppDb;Trusted_Connection=True;MultipleActiveResultSets=true;Encrypt=False"
}
3. Install Dependencies

Navigate to the React project directory and install the necessary Node.js packages:

cd path/to/your/react/project
npm install

4. Run the React Application

Start the React development server:

npm start
5. Run the .NET Application

Open a new terminal window.

Navigate to the .NET project directory and start the .NET application:

cd path/to/your/dotnet/project
dotnet run
6. Access the Application

Frontend: The React application should be running on http://localhost:3000 (or the port specified in your React configuration).

Backend: The .NET application should be running on http://localhost:5000 (or the port specified in your .NET configuration).

Note: Ensure that both the React and .NET applications are running simultaneously for the system to function properly.

For login, the seed data used is as follows:

   Email = "ensolvers@gmail.com"
   Password = "123456"


