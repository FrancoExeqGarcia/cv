﻿namespace backend.Data.Models.User
{
    public class VerifyPasswordDto
    {
        public int UserId { get; set; }
        public string Password { get; set; }
        public string NewPassword { get; set; }
    }
}
