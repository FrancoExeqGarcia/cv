﻿namespace backend.Data.Models.User
{
    public class UpdateUserPasswordDto
    {
        public int Id { get; set; }
        public string NewPassword { get; set; }
    }
}
