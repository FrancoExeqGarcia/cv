﻿using backend.Data.Entities;
using backend.Data.Models;
using backend.Data.Models.Tag;
using backend.Repositories.Interfaces;
using backend.Services.Interfaces;
using System.Collections.Generic;

namespace backend.Services.Implementations
{
    public class TagService : ITagService
    {
        private readonly ITagRepository _tagRepository;

        public TagService(ITagRepository tagRepository)
        {
            _tagRepository = tagRepository;
        }

        public TagDto CreateTag(CreateTagDto dto)
        {
            var tag = new Tag { Name = dto.Name };
            var createdTag = _tagRepository.Create(tag);

            return new TagDto
            {
                Id = createdTag.Id,
                Name = createdTag.Name
            };
        }

        public void DeleteTag(int id)
        {
            var tag = _tagRepository.GetById(id);
            if (tag == null) throw new Exception("Tag not found");
            _tagRepository.Delete(id);
        }

        public IEnumerable<TagDto> GetAllTags()
        {
            var tags = _tagRepository.GetAll();
            var tagDtos = new List<TagDto>();
            foreach (var tag in tags)
            {
                tagDtos.Add(new TagDto { Id = tag.Id, Name = tag.Name });
            }
            return tagDtos;
        }

        public IEnumerable<NoteDto> GetNotesByTag(int tagId)
        {
            var notes = _tagRepository.GetAll()
                .Where(t => t.Id == tagId)
                .SelectMany(t => t.NoteTags.Select(nt => nt.Note))
                .ToList();

            return notes.Select(note => new NoteDto
            {
                Id = note.Id,
                Title = note.Title,
                Content = note.Content,
                CreateAt = note.CreateAt,
                ArchivedAt = note.ArchivedAt,
                IsArchived = note.IsArchived
            }).ToList();
        }

        public TagDto GetTagById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
