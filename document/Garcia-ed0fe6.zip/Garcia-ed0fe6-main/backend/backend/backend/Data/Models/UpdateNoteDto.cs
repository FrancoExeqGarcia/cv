﻿using System.ComponentModel.DataAnnotations;
using static backend.Data.Entities.Note;

namespace backend.Data.Models
{
    public class UpdateNoteDto
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; } = string.Empty;
        [Required]
        public string Content { get; set; } = string.Empty ;
        [Required]
        public DateTime CreateAt { get; set; }
        [Required]
        public NoteStatus Status { get; set; } 

    }
}
