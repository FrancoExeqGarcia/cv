﻿using backend.Data.Models.Tag;
using backend.Data.Models;
using backend.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class TagsController : ControllerBase
{
    private readonly ITagService _tagService;

    public TagsController(ITagService tagService)
    {
        _tagService = tagService;
    }

    [HttpPost]
    public ActionResult<TagDto> Create([FromBody] CreateTagDto request)
    {
        var tagDto = _tagService.CreateTag(request);
        return CreatedAtAction(nameof(GetById), new { id = tagDto.Id }, tagDto);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        try
        {
            _tagService.DeleteTag(id);
            return NoContent();
        }
        catch (Exception)
        {
            return NotFound();
        }
    }

    [HttpGet]
    public ActionResult<IEnumerable<TagDto>> GetAll()
    {
        var tags = _tagService.GetAllTags();
        return Ok(tags);
    }

    [HttpGet("{id}")]
    public ActionResult<TagDto> GetById(int id)
    {
        var tag = _tagService.GetTagById(id);
        if (tag == null) return NotFound();
        return Ok(tag);
    }

    [HttpGet("{id}/notes")]
    public ActionResult<IEnumerable<NoteDto>> GetNotesByTag(int id)
    {
        var notes = _tagService.GetNotesByTag(id);
        return Ok(notes);
    }
}
