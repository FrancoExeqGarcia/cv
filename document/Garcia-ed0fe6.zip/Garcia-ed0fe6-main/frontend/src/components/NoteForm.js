import React, { useState, useEffect } from 'react';
import { createNote, updateNote, getNoteById } from '../data/AxiosConfig';

const NoteForm = ({ }) => {
  return (
    <>
      <p> holaaaaaaaaaaaaaassa</p>
    </>
  );
};

export default NoteForm;
